@echo off
chcp 65001 >nul
echo Установка зависимостей...
pip install customtkinter pyinstaller
echo.
echo Сборка самостоятельного exe...
pyinstaller --onefile --windowed --name "ShieldGuard" main.py
echo.
echo Готово. exe в папке dist\ShieldGuard.exe
pause
