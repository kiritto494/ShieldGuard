# -*- coding: utf-8 -*-
"""
Антивирус: поиск троянов, майнеров и угроз.
Режимы: сканирование папки, полное, быстрое.
"""

import os
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path

import customtkinter as ctk

from scanner_engine import (
    scan_directory,
    scan_file,
    get_quick_scan_paths,
    ScanResult,
    ThreatType,
)

# Тема и настройки
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

FONT_FAMILY = "Segoe UI"
COLORS = {
    "bg": "#0d1117",
    "card": "#161b22",
    "accent": "#58a6ff",
    "danger": "#f85149",
    "warning": "#d29922",
    "success": "#3fb950",
    "text": "#c9d1d9",
    "text_dim": "#8b949e",
}


class AntivirusApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("ShieldGuard — Антивирус")
        self.geometry("900x640")
        self.minsize(800, 560)
        self.configure(fg_color=COLORS["bg"])
        self._cancel_scan = threading.Event()
        self._scan_thread: threading.Thread | None = None
        self._scan_start_time: float = 0.0
        self._build_ui()
        self._bind_shortcuts()

    def _build_ui(self):
        # Заголовок
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=24, pady=(24, 16))
        title = ctk.CTkLabel(
            header,
            text="ShieldGuard",
            font=ctk.CTkFont(FONT_FAMILY, 28, weight="bold"),
            text_color=COLORS["accent"],
        )
        title.pack(side="left")
        subtitle = ctk.CTkLabel(
            header,
            text="Защита от троянов, майнеров и угроз",
            font=ctk.CTkFont(FONT_FAMILY, 13),
            text_color=COLORS["text_dim"],
        )
        subtitle.pack(side="left", padx=(12, 0), pady=(6, 0))

        # Карточка режимов
        modes_frame = ctk.CTkFrame(self, fg_color=COLORS["card"], corner_radius=12, border_width=0)
        modes_frame.pack(fill="x", padx=24, pady=(0, 16))
        modes_inner = ctk.CTkFrame(modes_frame, fg_color="transparent")
        modes_inner.pack(fill="x", padx=20, pady=20)
        ctk.CTkLabel(
            modes_inner,
            text="Режим сканирования",
            font=ctk.CTkFont(FONT_FAMILY, 14, weight="bold"),
            text_color=COLORS["text"],
        ).pack(anchor="w")
        ctk.CTkLabel(
            modes_inner,
            text="Выберите папку или один из режимов сканирования",
            font=ctk.CTkFont(FONT_FAMILY, 12),
            text_color=COLORS["text_dim"],
        ).pack(anchor="w")
        btn_frame = ctk.CTkFrame(modes_inner, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(14, 0))
        self.btn_folder = ctk.CTkButton(
            btn_frame,
            text="Папка",
            font=ctk.CTkFont(FONT_FAMILY, 13),
            width=140,
            height=40,
            corner_radius=8,
            fg_color=COLORS["accent"],
            hover_color="#79b8ff",
            command=self._on_scan_folder,
        )
        self.btn_folder.pack(side="left", padx=(0, 10))
        self.btn_full = ctk.CTkButton(
            btn_frame,
            text="Полное сканирование",
            font=ctk.CTkFont(FONT_FAMILY, 13),
            width=180,
            height=40,
            corner_radius=8,
            fg_color=COLORS["card"],
            border_width=1,
            border_color=COLORS["text_dim"],
            hover_color=COLORS["text_dim"],
            command=self._on_full_scan,
        )
        self.btn_full.pack(side="left", padx=(0, 10))
        self.btn_quick = ctk.CTkButton(
            btn_frame,
            text="Быстрое сканирование",
            font=ctk.CTkFont(FONT_FAMILY, 13),
            width=180,
            height=40,
            corner_radius=8,
            fg_color=COLORS["card"],
            border_width=1,
            border_color=COLORS["text_dim"],
            hover_color=COLORS["text_dim"],
            command=self._on_quick_scan,
        )
        self.btn_quick.pack(side="left")
        self.shortcuts_label = ctk.CTkLabel(
            modes_inner,
            text="Ярлыки: Ctrl+1 — папка  |  Ctrl+2 — полное  |  Ctrl+3 — быстрое  |  Esc — остановить",
            font=ctk.CTkFont(FONT_FAMILY, 11),
            text_color=COLORS["text_dim"],
        )
        self.shortcuts_label.pack(anchor="w", pady=(10, 0))

        # Текущая папка
        path_frame = ctk.CTkFrame(self, fg_color="transparent")
        path_frame.pack(fill="x", padx=24, pady=(0, 8))
        self.path_label = ctk.CTkLabel(
            path_frame,
            text="Папка не выбрана",
            font=ctk.CTkFont(FONT_FAMILY, 11),
            text_color=COLORS["text_dim"],
            anchor="w",
        )
        self.path_label.pack(fill="x")

        # Прогресс
        progress_frame = ctk.CTkFrame(self, fg_color="transparent")
        progress_frame.pack(fill="x", padx=24, pady=(0, 8))
        self.progress = ctk.CTkProgressBar(progress_frame, height=6, corner_radius=3, progress_color=COLORS["accent"])
        self.progress.pack(fill="x")
        self.progress.set(0)
        self.status_label = ctk.CTkLabel(
            progress_frame,
            text="Готов к сканированию",
            font=ctk.CTkFont(FONT_FAMILY, 12),
            text_color=COLORS["text_dim"],
            anchor="w",
        )
        self.status_label.pack(fill="x", pady=(6, 0))

        # Кнопка остановки
        self.btn_stop = ctk.CTkButton(
            self,
            text="Остановить",
            font=ctk.CTkFont(FONT_FAMILY, 12),
            width=120,
            height=32,
            fg_color=COLORS["danger"],
            hover_color="#da3633",
            command=self._on_stop,
            state="disabled",
        )
        self.btn_stop.pack(anchor="e", padx=24, pady=(0, 8))

        # Результаты
        results_frame = ctk.CTkFrame(self, fg_color=COLORS["card"], corner_radius=12)
        results_frame.pack(fill="both", expand=True, padx=24, pady=(0, 24))
        ctk.CTkLabel(
            results_frame,
            text="Результаты",
            font=ctk.CTkFont(FONT_FAMILY, 14, weight="bold"),
            text_color=COLORS["text"],
        ).pack(anchor="w", padx=20, pady=(16, 8))
        self.results_text = ctk.CTkTextbox(
            results_frame,
            font=ctk.CTkFont("Consolas", 11),
            fg_color="#0d1117",
            text_color=COLORS["text"],
            wrap="word",
            corner_radius=8,
        )
        self.results_text.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.results_text.insert("end", "Здесь будут отображаться найденные угрозы.\n")
        self.results_text.configure(state="disabled")
        try:
            for tag, color in [
                ("success", COLORS["success"]),
                ("danger", COLORS["danger"]),
                ("threat", COLORS["warning"]),
                ("dim", COLORS["text_dim"]),
                ("path", COLORS["accent"]),
            ]:
                self.results_text.tag_configure(tag, foreground=color)
        except Exception:
            pass

    def _set_scanning(self, scanning: bool):
        state = "disabled" if scanning else "normal"
        self.btn_folder.configure(state=state)
        self.btn_full.configure(state=state)
        self.btn_quick.configure(state=state)
        self.btn_stop.configure(state="normal" if scanning else "disabled")

    def _format_remaining(self, remaining_sec: float) -> str:
        if remaining_sec <= 0 or remaining_sec >= 86400:
            return "—"
        if remaining_sec >= 60:
            m = int(remaining_sec // 60)
            s = int(remaining_sec % 60)
            return f"{m} мин {s} сек" if s else f"{m} мин"
        return f"{int(remaining_sec)} сек"

    def _update_progress(self, current: int, total: int):
        if total > 0:
            self.after(0, lambda: self.progress.set(min(1.0, current / total)))
        # Оценка оставшегося времени
        status_text = f"Сканировано: {current} / {total}"
        if total > 0 and current > 0 and current < total and self._scan_start_time > 0:
            elapsed = time.time() - self._scan_start_time
            if elapsed > 0.5:
                rate = current / elapsed
                remaining_sec = (total - current) / rate
                status_text += f"  |  Осталось: ~{self._format_remaining(remaining_sec)}"
        self.after(0, lambda: self.status_label.configure(text=status_text))

    def _update_status(self, text: str):
        self.after(0, lambda: self.status_label.configure(text=text))

    def _show_results(self, results: list[ScanResult], mode_name: str):
        self.results_text.configure(state="normal")
        self.results_text.delete("1.0", "end")
        if not results:
            self.results_text.insert("end", f"[{mode_name}] Угроз не обнаружено.\n", "success")
        else:
            self.results_text.insert("end", f"[{mode_name}] Найдено угроз: {len(results)}\n\n", "danger")
            for r in results:
                sev = "Критично" if r.severity >= 3 else "Высоко" if r.severity == 2 else "Средне"
                self.results_text.insert("end", f"• {r.threat_type} — {sev}\n", "threat")
                self.results_text.insert("end", f"  {r.description}\n", "dim")
                self.results_text.insert("end", f"  Путь: {r.path}\n\n", "path")
        self.results_text.configure(state="disabled")

    def _run_scan(self, root_path: str, quick: bool, mode_name: str):
        self._cancel_scan.clear()
        self._set_scanning(True)
        self._scan_start_time = time.time()
        self.progress.set(0)
        self._update_status("Подготовка...")
        results: list[ScanResult] = []

        def progress_cb(path: str, scanned: int, total: int):
            self._update_progress(scanned, total)

        def do_scan():
            try:
                self.after(0, lambda: self._update_status("Сканирование..."))
                res = scan_directory(
                    root_path,
                    quick=quick,
                    progress_cb=progress_cb,
                    cancel_flag=self._cancel_scan,
                )
                results.extend(res)
            except Exception as e:
                self.after(0, lambda: self._update_status(f"Ошибка: {e}"))
            finally:
                self.after(0, lambda: self._finish_scan(results, mode_name))

        self._scan_thread = threading.Thread(target=do_scan, daemon=True)
        self._scan_thread.start()

    def _finish_scan(self, results: list[ScanResult], mode_name: str):
        self._set_scanning(False)
        self.progress.set(1.0)
        self._update_status("Сканирование завершено.")
        self._show_results(results, mode_name)
        self._scan_thread = None

    def _on_scan_folder(self):
        folder = filedialog.askdirectory(title="Выберите папку для сканирования")
        if not folder:
            return
        self.path_label.configure(text=folder)
        self._run_scan(folder, quick=False, mode_name="Сканирование папки")

    def _on_full_scan(self):
        drives = [f"{letter}:\\" for letter in "CDEFGH" if os.path.isdir(f"{letter}:\\")]
        if not drives:
            drives = ["C:\\"]
        self.path_label.configure(text="Все диски (полное сканирование)")
        self._set_scanning(True)
        self._cancel_scan.clear()
        self._scan_start_time = time.time()
        self.progress.set(0)
        all_results: list[ScanResult] = []
        scanned_total = [0]
        approx_total = [len(drives) * 50000]

        def do_full():
            try:
                for root in drives:
                    if self._cancel_scan.is_set():
                        break
                    self.after(0, lambda r=root: self._update_status(f"Полное сканирование: {r}"))
                    res = scan_directory(
                        root,
                        quick=False,
                        progress_cb=lambda p, s, t: self.after(0, lambda: self._update_progress(scanned_total[0] + s, approx_total[0])),
                        cancel_flag=self._cancel_scan,
                    )
                    all_results.extend(res)
                    scanned_total[0] += 50000
            except Exception as e:
                self.after(0, lambda: self._update_status(str(e)))
            finally:
                self.after(0, lambda: self._finish_scan(all_results, "Полное сканирование"))

        self._scan_thread = threading.Thread(target=do_full, daemon=True)
        self._scan_thread.start()

    def _on_quick_scan(self):
        paths = get_quick_scan_paths()
        if not paths:
            paths = [os.path.expanduser("~")]
        self.path_label.configure(text="Быстрое сканирование (временные и ключевые папки)")
        self._set_scanning(True)
        self._cancel_scan.clear()
        self._scan_start_time = time.time()
        self.progress.set(0)
        all_results: list[ScanResult] = []

        cnt = [0]
        tot = [max(len(paths) * 500, 1)]

        def do_quick():
            try:
                for root in paths:
                    if self._cancel_scan.is_set():
                        break
                    self.after(0, lambda r=root: self._update_status(f"Быстрое сканирование: {r}"))
                    res = scan_directory(
                        root,
                        quick=True,
                        progress_cb=lambda p, s, t: self.after(0, lambda: self._update_progress(cnt[0] + s, tot[0])),
                        cancel_flag=self._cancel_scan,
                    )
                    all_results.extend(res)
                    cnt[0] += 500
            except Exception as e:
                self.after(0, lambda: self._update_status(str(e)))
            finally:
                self.after(0, lambda: self._finish_scan(all_results, "Быстрое сканирование"))

        self._scan_thread = threading.Thread(target=do_quick, daemon=True)
        self._scan_thread.start()

    def _on_stop(self):
        self._cancel_scan.set()
        self._update_status("Остановка...")

    def _bind_shortcuts(self):
        self.bind("<Control-1>", lambda e: self._on_scan_folder())
        self.bind("<Control-2>", lambda e: self._on_full_scan())
        self.bind("<Control-3>", lambda e: self._on_quick_scan())
        self.bind("<Control-q>", lambda e: self._on_quick_scan())
        self.bind("<Control-f>", lambda e: self._on_full_scan())
        self.bind("<Escape>", lambda e: self._on_stop() if self.btn_stop.cget("state") == "normal" else None)


def main():
    app = AntivirusApp()
    app.mainloop()


if __name__ == "__main__":
    main()
