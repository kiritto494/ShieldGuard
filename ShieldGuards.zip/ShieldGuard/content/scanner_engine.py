# -*- coding: utf-8 -*-
"""
Движок сканирования: поиск троянов, майнеров и подозрительных паттернов.
"""

import os
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Callable, Optional
import threading

class ThreatType:
    MINER = "Криптомайнер"
    TROJAN = "Троян"
    KEYLOGGER = "Кейлоггер"
    RAT = "Удалённый доступ (RAT)"
    SUSPICIOUS = "Подозрительный файл"
    SCRIPT_INJECT = "Внедрение скрипта"
    OBFUSCATED = "Обфусцированный код"


@dataclass
class ScanResult:
    path: str
    threat_type: str
    description: str
    severity: int  # 1-3
    signature_name: Optional[str] = None


# Сигнатуры для обнаружения майнеров (части URL, строки в коде)
MINER_SIGNATURES = [
    (r"stratum\+tcp", ThreatType.MINER, "Stratum mining pool", 3),
    (r"xmrig|minergate|nicehash|monero|xmr\.pool", ThreatType.MINER, "Криптомайнер", 3),
    (r"pool\.mine", ThreatType.MINER, "Mining pool", 3),
    (r"crypto.*mining|mining.*crypto", ThreatType.MINER, "Mining", 3),
    (r"hashrate|hash\.rate|getwork|submitwork", ThreatType.MINER, "Mining API", 3),
    (r"coinhive|authedmine|minero\.cc|webassembly.*mining", ThreatType.MINER, "Браузерный майнер", 3),
    (r"\.mine\(|mining\s*=|startMining|stopMining", ThreatType.MINER, "Mining вызов", 3),
]

# Сигнатуры троянов и вредоносного ПО
TROJAN_SIGNATURES = [
    (r"keylogger|keylog|GetAsyncKeyState|GetKeyState", ThreatType.KEYLOGGER, "Кейлоггер", 3),
    (r"reverse_shell|reverse shell|bind_shell|cmd\.exe.*hidden", ThreatType.TROJAN, "Reverse shell", 3),
    (r"AddToStartup|Registry\.SetValue.*Run|HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run", ThreatType.TROJAN, "Автозапуск", 2),
    (r"Process\.Start.*cmd|ShellExecute.*hidden|CreateProcess.*SW_HIDE", ThreatType.TROJAN, "Скрытый процесс", 3),
    (r"ScreenCapture|screenshot|Bitmap.*Save|CaptureScreen", ThreatType.RAT, "Захват экрана", 2),
    (r"RemoteDesktop|VNC|TeamViewer.*auto|anydesk", ThreatType.RAT, "Удалённый доступ", 2),
    (r"Credential\.|Password.*steal|browser.*password|chrome.*login", ThreatType.TROJAN, "Кража учётных данных", 3),
    (r"eval\s*\(\s*base64|exec\s*\(\s*decode|FromBase64String.*Invoke", ThreatType.OBFUSCATED, "Обфускация/декодирование", 2),
    (r"Invoke-Expression|IEX\s*\(|powershell.*-enc|EncodedCommand", ThreatType.SCRIPT_INJECT, "Выполнение скрипта", 2),
    (r"document\.write\s*\(\s*eval|innerHTML\s*=.*eval|script.*document\.cookie", ThreatType.SCRIPT_INJECT, "Инъекция в страницу", 2),
    (r"WScript\.Shell|Scripting\.FileSystemObject.*Delete|FormatC", ThreatType.TROJAN, "Опасный скрипт", 2),
    (r"DownloadFile|WebClient\.Download|HttpReq.*body|wget.*-O", ThreatType.TROJAN, "Загрузка файлов", 1),
    (r"\\x[0-9a-fA-F]{2}\\x[0-9a-fA-F]{2}\\x[0-9a-fA-F]{2}", ThreatType.OBFUSCATED, "Шелл-код/обфускация", 2),
]

# Подозрительные расширения (часто используются в малвари)
SUSPICIOUS_EXTENSIONS = {".scr", ".vbs", ".vbe", ".wsf", ".wsh", ".ps1", ".psm1", ".jar", ".bat", ".cmd", ".hta"}
# Расширения, которые сканируем по содержимому
SCANNABLE_EXTENSIONS = {".py", ".js", ".vbs", ".ps1", ".bat", ".cmd", ".html", ".htm", ".php", ".asp", ".aspx", ".exe", ".dll", ".txt", ".log", ".config", ".xml", ".json", ""}

# Известные опасные пути (для быстрого сканирования)
SUSPICIOUS_PATHS = [
    os.environ.get("TEMP", ""),
    os.environ.get("TMP", ""),
    os.path.expanduser("~\\AppData\\Local\\Temp"),
    os.path.expanduser("~\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"),
    os.path.expanduser("~\\AppData\\Local\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"),
]

# Максимальный размер файла для чтения (МБ)
MAX_SCAN_SIZE_MB = 15


def _read_file_safe(path: str, max_bytes: int) -> Optional[bytes]:
    try:
        with open(path, "rb") as f:
            return f.read(max_bytes)
    except (OSError, PermissionError, UnicodeDecodeError):
        return None


def _decode_for_scan(data: bytes) -> str:
    for enc in ("utf-8", "utf-16", "latin-1", "cp1251"):
        try:
            return data.decode(enc, errors="ignore")
        except Exception:
            continue
    return data.decode("utf-8", errors="replace")


def _check_signatures(content: str, path: str) -> list[ScanResult]:
    results = []
    content_lower = content.lower()
    for pattern, threat_type, desc, severity in MINER_SIGNATURES + TROJAN_SIGNATURES:
        if re.search(pattern, content_lower, re.IGNORECASE):
            results.append(ScanResult(
                path=path,
                threat_type=threat_type,
                description=desc,
                severity=severity,
                signature_name=pattern[:50],
            ))
    return results


def _should_scan_file(path: str, quick: bool) -> bool:
    ext = Path(path).suffix.lower()
    if quick:
        # Быстрое: только подозрительные расширения и опасные пути
        base = path.lower()
        in_suspicious_path = any(p and p.lower() in base for p in SUSPICIOUS_PATHS if p)
        return ext in SUSPICIOUS_EXTENSIONS or (in_suspicious_path and ext in {".exe", ".dll", ".bat", ".ps1", ".vbs"})
    return ext in SCANNABLE_EXTENSIONS or not ext


def scan_file(path: str, quick: bool = False, progress_cb: Optional[Callable[[str], None]] = None) -> list[ScanResult]:
    if progress_cb:
        progress_cb(path)
    if not os.path.isfile(path):
        return []
    if not _should_scan_file(path, quick):
        return []
    max_bytes = MAX_SCAN_SIZE_MB * 1024 * 1024
    data = _read_file_safe(path, max_bytes)
    if not data:
        return []
    text = _decode_for_scan(data)
    return _check_signatures(text, path)


def scan_directory(
    root: str,
    quick: bool = False,
    progress_cb: Optional[Callable[[str, int, int], None]] = None,
    cancel_flag: Optional[threading.Event] = None,
) -> list[ScanResult]:
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return []
    all_results = []
    total = 0
    for _ in Path(root).rglob("*"):
        total += 1
    scanned = 0
    try:
        for entry in Path(root).rglob("*"):
            if cancel_flag and cancel_flag.is_set():
                break
            if not entry.is_file():
                continue
            path = str(entry)
            try:
                res = scan_file(path, quick=quick)
                all_results.extend(res)
            except Exception:
                pass
            scanned += 1
            if progress_cb and scanned % 50 == 0:
                progress_cb(path, scanned, total)
        if progress_cb and scanned > 0:
            progress_cb(path, scanned, total)
    except PermissionError:
        pass
    return all_results


def get_quick_scan_paths() -> list[str]:
    paths = []
    for p in SUSPICIOUS_PATHS:
        if p and os.path.isdir(p):
            paths.append(p)
    # Диски C:\, типичные места
    for letter in "CDEF":
        d = f"{letter}:\\"
        if os.path.isdir(d):
            paths.append(d)
    return paths
